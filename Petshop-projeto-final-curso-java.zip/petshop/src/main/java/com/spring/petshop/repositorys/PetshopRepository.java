package com.spring.petshop.repositorys;

import org.springframework.data.repository.CrudRepository;

import com.spring.petshop.models.Cliente;

public interface PetshopRepository extends CrudRepository<Cliente, String> {
	Cliente findByIdCliente(long idCliente);
	Cliente deleteByIdCliente(long idCliente);
}
