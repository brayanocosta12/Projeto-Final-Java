package com.spring.petshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.petshop.models.Cliente;
import com.spring.petshop.repositorys.PetshopRepository;



@Controller
public class PetshopController {
	
		
	// Clientes
		@Autowired
		private PetshopRepository csr;

		@RequestMapping(value="/cadastrarClientes", method=RequestMethod.GET)
		public String cadastrarCliente() {
			return "crud/cadastro-cliente";
		}
		
		@RequestMapping(value="/cadastrarClientes", method=RequestMethod.POST)
		public String cadastrarCliente(Cliente cliente) {
			csr.save(cliente);
			return "redirect:/";
		}
		
		@RequestMapping("/")
		public ModelAndView listarCliente() {
			ModelAndView mv = new ModelAndView("index");
			Iterable<Cliente> clientes = csr.findAll();
			mv.addObject("clientes", clientes);
			return mv;
		}
		
		@RequestMapping(value="/alterarCliente/{idCliente}", method=RequestMethod.GET)
		public ModelAndView alterarCliente(@PathVariable("idCliente") long idCliente) {
			Cliente cliente = csr.findByIdCliente(idCliente);
			ModelAndView mv = new ModelAndView("crud/alterar-cliente");
			mv.addObject("cliente", cliente);
			return mv;
		}
		
		@RequestMapping(value="/alterarCliente/{idCliente}", method=RequestMethod.POST)
		public String atualizarCliente(@Validated Cliente cliente, BindingResult result, RedirectAttributes attributes) {
			csr.save(cliente);
			return "redirect:/";
		}
		
		@RequestMapping("/confirmarExclusaoCliente/{idCliente}")
		public ModelAndView confirmarExclusaoCliente(@PathVariable("idCliente") long idCliente) {
			Cliente cliente = csr.findByIdCliente(idCliente);
			ModelAndView mv = new ModelAndView("crud/excluir-cliente");
			mv.addObject("cliente", cliente);
			return mv;
		}
		
		@RequestMapping("/excluirCliente")
		public String excluirCliente(long idCliente) {
			Cliente cliente = csr.findByIdCliente(idCliente);
			csr.delete(cliente);
			return "redirect:/";
		}
}
